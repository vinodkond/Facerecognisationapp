package com.example.facerecognitionapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
